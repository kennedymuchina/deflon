import 'package:deflon/widgets/drawer_menu.dart';
import 'package:flutter/material.dart';
import 'package:deflon/widgets/bottom_select.dart';

class Home extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      drawer: DrawerMenu(),
      body: SafeArea(
        top: true,
        child: Stack(
          children: <Widget>[
            Container(
              child: Center(
                child: Text('Loading maps...')
              ),
            ),
            Align(
              alignment: Alignment.bottomCenter,
              child: Container(
                height: 170,
                width: MediaQuery.of(context).size.width,
                decoration: BoxDecoration(
                  color: Colors.white,
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black12,
                      blurRadius: 4.0,
                      spreadRadius: 2.0
                    )]),
                child: ListView(
                  children: <Widget>[
                    BottomSelect(),
                  ],
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}
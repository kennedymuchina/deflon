import 'package:deflon/widgets/drawer_menu.dart';
import 'package:flutter/material.dart';

class BookRide extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      top: true,
      child: Scaffold(
        appBar: AppBar(),
        drawer: DrawerMenu(),
        body: GestureDetector(
          child: Container(
            child: Center(
              child: Hero(tag: 'search_button', child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    FlatButton.icon(onPressed: (){
                      Navigator.pop(context);
                      },
                      icon: Icon(Icons.arrow_back),
                      label: Text('Go back')),
                  ],
                ),
              ))
            ),
          ),
        )
      ),
    );
  }
}

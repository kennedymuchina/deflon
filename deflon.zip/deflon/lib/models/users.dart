import 'package:cloud_firestore/cloud_firestore.dart';

class UserServices{
  Firestore _fireStore = Firestore.instance;
  String collection = "users";
  void createUser(Map data) {
    _fireStore.collection(collection).document("userId").setData(data);
  }
}